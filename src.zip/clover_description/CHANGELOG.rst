^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package clover_description
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.21.1 (2020-11-17)
-------------------
* First release of clover_description package to ROS
* Contributors: Alexey Rogachevskiy

